from django.apps import AppConfig


class YoutubeDownloaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'youtube_downloader'
